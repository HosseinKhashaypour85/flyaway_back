const createRowTicketView = async (req , res) => {
    const {image_url , ticketTitle} = req.body;
}